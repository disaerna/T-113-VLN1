# T-113-VLN1
Verklegt námskeið 1
Háskólinn í Reykjavík

                                                       Hópur 27

Þátttakendur:
  •	Ásdís Erna Guðmundsdóttir
  •	Elín Edda Sigurðardóttir
  •	Haukur Júlíus Arnarsson
  •	Sandra Ómarsdóttir
  •	Karl Arnar Ægisson
  •	Viktoría Einarsdóttir


Vika 1
Verkefnið okkar gekk út á það að búa til forrit sem gerði notanda kleift að skrá upplýsingar um manneskjur (nafn, kyn, fæðingarár og dánarár), leita, eyða og sortera svo í þær upplýsingar.
Við ákveðum að vinna þetta í pörum til að reyna passa að allir væru með og þeir sem kunnu minna gætu því “lært” af þeim sem kunnu meira,
þetta sést greinilega með því að skoða GitHub sumir hópmeðlimir láta mest allt inn.
Einnig er vert að nefna vegna tæknilegra erfiðleika (sem var búið að tala við Daníel Brand um) höfðum við bara aðgang að ákveðnum tölvum í byrjun verkefnisins.

Vika 2
Verkefnið sem við fengum í þessari viku var að gera forrit sem gerði notanda kleift að geta skráð þekktar tölvur úr sögu tölvunarfræðinnar (nafn, byggingar ár, tegund og hvort það hafði tekist að byggja hana) ásamt vísindamönnum þeirra. Einnig átti að vera hægt að tengja tölvur og vísindamennina sem byggðu hana saman og leitað á mismunandi hætti í þessum upplýsingum.
Sem auka virkni er einnig hægt að eyða út vísindamönnum, tölvum og tengingum þeirra á milli ásamt því að hægt er að breyta upplýsingum eftir að þeim hefur verið bætt við gagnagrunn.
í síðustu viku fannst okkur skipulagið á hvernig við unnum verkefnið vanta og reyndum að bæta það í þessari viku. Það gekk ágætlega en vegna (aftur) tæknilegra erfiðleika neyddumst við til að skiptast á tölvum og vinna saman. Einnig unnu sumir í hópnum sem  "leitarvélar" og sendu á hina upplýsingarnar sem þau fundu til að geta leyst vandamál í kóðanum, vegna þessa voru sumir sem push-uðu lítið í GitHub.
Það þarf að bæta við QT bin möppunni í PATH til að .exe skrá keyri. Lentum í vandræðum með að keyra skránna og þrátt fyrir að bæta möppunni við keyrir hún þegar henni hentar.

Vika 3
Verkefnið okkar á seinustu vikunni í þriggja vika áfanga okkar var að láta forritið yfir í Qt-Gui. Við máttum ráða útlitinu en fengum ákveðin skilyrði um hvað ætti að vera framkvæmalegt eins og geta skráð, breytt, birt lista af upplýsingum um þekkta tölvunarfræðinga og tölvur, geta gert tengingu milli þeirra og gera allt notendavænt. 
Skipulagið var í þessari viku var mun betra, hver fékk sitt verkefni og vann í því heima. Okkur finnst best að hafa "leitarvélar" og error checkara sem gerir það að verkum að pushinn í Git-hub eru mjög ójöfn. Þessi aðferð er sú sem hentaði okkur best og tæknilegu erfiðleikana sem við lentum svo oft í með þetta verkefni. 

Slóð á kóða: https://github.com/disaerna/T-113-VLN1/
