# T-113-VLN1
Verklegt námskeið 1
Háskólinn í Reykjavík

                                                       Hópur 27

Þátttakendur:
  •	Ásdís Erna Guðmundsdóttir
  •	Elín Edda Sigurðardóttir
  •	Haukur Júlíus Arnarsson
  •	Sandra Ómarsdóttir
  •	Karl Arnar Ægisson
  •	Viktoría Einarsdóttir

Verkefnið okkar gekk út á það að búa til forrit sem gerði notanda kleift að skrá upplýsingar um manneskjur (nafn, kyn, fæðingarár og dánarár), leita, eyða og sortera svo í þær upplýsingar. 
Við ákveðum að vinna þetta í pörum til að reyna passa að allir væru með og þeir sem kunnu minna gætu því “lært” af þeim sem kunnu meira, 
þetta sést greinilega með því að skoða GitHub sumir hópmeðlimir láta mest allt inn. 
Einnig er vert að nefna vegna tæknilegra erfiðleika (sem var búið að tala við Daníel Brand um) höfðum við bara aðgang að ákveðnum tölvum í byrjun verkefnisins.
Slóð á kóða: https://github.com/disaerna/T-113-VLN1/

