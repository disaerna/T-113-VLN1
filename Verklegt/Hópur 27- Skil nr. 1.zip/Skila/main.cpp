#include "presentation.h"

using namespace std;

int main()
{
    Presentation pres;

    pres.splashMessage(); // Displays computer scientists message.
    pres.program(); // Runs program.

    return 0;
}
